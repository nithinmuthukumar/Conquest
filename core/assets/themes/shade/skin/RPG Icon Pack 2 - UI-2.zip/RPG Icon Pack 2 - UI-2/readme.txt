RPG Icon Pack 2 - UI
by 7Soul - @7SoulDesign
http://7soul1.deviantart.com/

Font used in preview is BetterPixels by AmericanHamster
http://www.pentacom.jp/pentacom/bitfontmaker2/gallery/?id=102